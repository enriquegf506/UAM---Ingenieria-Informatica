#include "menu.h"
#include "products.h"
#include "orders.h"
#include "customers.h"

static	int ShowMainMenu() {
    int nSelected = 0;
    int i = 0;
    char buf[16]; /* buffer for reading user input
                     in theory we only need 1 char
                     but a large buffer will handle
                     more gracefully wrong inputs
                     as 'qwerty' */

    do {
        printf("This is a menu for our store\n");
        printf("You can choose to see things about products, orders or customers.\n\n");

        printf(" (1) Products\n"
               " (2) Orders\n"
               " (3) Customers\n"
               " (4) Exit\n\n"
               "Enter a number that corresponds to your choice > ");
               nSelected = 0;
        if (!fgets(buf, 16, stdin))
            /* reading input failed, give up: */
            nSelected =0;
        else
        {
            /* have some input, convert it to integer: */
            while(buf[i] != '\0')
            {
                if (isalpha(buf[i]))
                {
                    nSelected = 5;
                    break;
                }
                i++;
            }
            if (nSelected != 5)
                nSelected = atoi(buf);
        }
        printf("\n");

        if ((nSelected < 1) || (nSelected > 4)) {
            printf("You have entered an invalid choice. Please try again\n\n\n");
        }
    } while ((nSelected < 1) || (nSelected > 4));

    return nSelected;
}

/**
 * @brief prints products menu and allows to select an option.
 *
 * @return selected option
 * @author Marcos Alonso and Enrique Gómez
 */

static	int ShowProductsSubMenu() {
    int nSelected = 0;
    int i = 0;
    char buf[16];

    do {

        printf(" (1) Stock\n"
               " (2) Find\n"
               " (3) Back\n\n");

        printf("Enter a number that corresponds to your choice > ");
        nSelected = 0;
        if (!fgets(buf, 16, stdin))
            /* reading input failed, give up: */
            nSelected =0;
        else
        {
            /* have some input, convert it to integer: */
            while(buf[i] != '\0')
            {
                if (isalpha(buf[i]))
                {
                    nSelected = 5;
                    break;
                }
                i++;
            }
            if (nSelected != 5)
                nSelected = atoi(buf);
        }
        printf("\n");


        if ((nSelected < 1) || (nSelected > 3)) {
            printf("You have entered an invalid choice. Please try again\n\n\n");
        }
    } while ((nSelected < 1) || (nSelected > 3));

    return nSelected;
}

/**
 * @brief Shows and processes the products menu.
 *
 * This function implements a loop that prints the order
 * menu, analyze the user selection and prints
 * the selected product instruction
 * @return void
 * @author Marcos Alonso and Enrique Gómez
 */

static	void ShowProductsMenu() {
    int nChoice = 0;

    do {
        nChoice = ShowProductsSubMenu();
        switch (nChoice) {

            case 1: {
                products_stock();
            }
                break;

            case 2: {
                products_find();
            }
                break;

            case 3: {
                printf("Bye Bye\n\n");
            }
                break;
        }
    } while (nChoice != 3);

}

/**
 * @brief prints the orders menu and allows to select an option.
 *
 * @return selected option
 * @author Marcos Alonso and Enrique Gómez
 */
static int ShowOrdersSubMenu() {
    int nSelected = 0;
    char buf[16];

    do {

        printf(" (1) Open\n"
               " (2) Range\n"
               " (3) Detail\n"
               " (4) Back\n\n");

        printf("Enter a number that corresponds to your choice > ");
        if (!fgets(buf, 16, stdin))
            /* reading input failed, give up: */
            nSelected =0;
        else
            /* have some input, convert it to integer: */
            nSelected = atoi(buf);
        printf("\n");

        if ((nSelected < 1) || (nSelected > 4)) {
            printf("You have entered an invalid choice. Please try again\n\n\n");
        }
    } while ((nSelected < 1) || (nSelected > 4));

    return nSelected;
}

/**
 * @brief Shows and processes the orders menu.
 *
 * This function implements a loop that prints the orders
 * menu, analyze the user selection and prints
 * the selected orders instruccion
 *
 * @return selected option
 * @author Marcos Alonso and Enrique Gómez
 */

static void ShowOrdersMenu() {
    int nChoice = 0;

    do {
        nChoice = ShowOrdersSubMenu();
        switch (nChoice) {
            case 1: {
                orders_open();
            }
            
            break;

            case 2: {
                orders_range();
            }
                break;

            case 3: {
                orders_detail();
            }
                break;

            case 4: {
                printf("Bye Bye\n\n");
            }
                break;
        }
    } while (nChoice != 4);

}

static int ShowCustomersSubMenu() {
    int nSelected = 0;
    char buf[16];

    do {

        printf(" (1) Find\n"
               " (2) List products\n"
               " (3) Balance\n"
               " (4) Back\n\n");

        printf("Enter a number that corresponds to your choice > ");
        if (!fgets(buf, 16, stdin))
            /* reading input failed, give up: */
            nSelected =0;
        else
            /* have some input, convert it to integer: */
            nSelected = atoi(buf);
        printf("\n");

        if ((nSelected < 1) || (nSelected > 4)) {
            printf("You have entered an invalid choice. Please try again\n\n\n");
        }
    } while ((nSelected < 1) || (nSelected > 4));

    return nSelected;
}

static void ShowCustomersMenu() {
    int nChoice = 0;

    do {
        nChoice = ShowCustomersSubMenu();
        switch (nChoice) {
            case 1: {
                customers_find();
            }
                break;

            case 2: {
                customers_list_products();
            }
                break;

            case 3: {
                customers_balance();
            }
                break;

            case 4: {
                printf("Bye Bye\n\n");
            }
                break;
        }
    } while (nChoice != 4);
}

int main(void) {
    int nChoice = 0;

    do {
        nChoice = ShowMainMenu();
        switch (nChoice) {
            case 1: {
                ShowProductsMenu();
            }
                break;

            case 2: {
                ShowOrdersMenu();
            }
                break;

            case 3: {
                ShowCustomersMenu();
            }
                break;
            
            case 4: {
                printf("Bye Bye\n\n");
            }
                break;
        }

        
    } while (nChoice != 4);
	return 0;
}
     
