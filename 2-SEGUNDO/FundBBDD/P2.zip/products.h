#include "menu.h"

void	products_stock();
void	products_find();