#include "menu.h"
#include "customers.h"

// Función que ejecuta la query correspondiente a la orden find de customers
// Autores: Marcos Alonso y Enrique Gómez

void customers_find()
{
	int ret = 0;
	int ret2 = 0;
	SQLHSTMT stmt = NULL;
	SQLHENV env = NULL;
	SQLHDBC dbc = NULL;
	int	j = 0;
	int i = 0;
	int u = 0;
	int	page = 0;
	int flag = 0;
	char ***buffer;
	char x[BufferLength] = "\0";
	char y[BufferLength] = "\0";
	char q[BufferLength] = "\0";
	char p[BufferLength] = "\0";
	char l[BufferLength] = "\0";

	ret = odbc_connect(&env, &dbc);
	if (!SQL_SUCCEEDED(ret))
	{
		return;
	}
	ret = SQLAllocHandle(SQL_HANDLE_STMT, dbc, &stmt);
	ret = SQLPrepare(stmt, (SQLCHAR *)"select customers.customernumber, customername, contactfirstname, contactlastname from customers where contactfirstname like ? or contactlastname like ? order by customernumber", SQL_NTS);
	if (!SQL_SUCCEEDED(ret))
	{
		odbc_extract_error("", stmt, SQL_HANDLE_ENV);
		return;
	}
	printf("Enter customer name > ");
	(void)fflush(stdout);
	if (fgets(x, (int)sizeof(x), stdin) != NULL)
	{
		buffer = malloc(sizeof(char **) * 1500);
		x[strlen(x) - 1] = (char)0;
		char z[BufferLength] = "\0";
		strcat(z, "%");
		strcat(z, x);
		strcat(z, "%");
		(void)SQLBindParameter(stmt, 1, SQL_PARAM_INPUT,
							   SQL_C_CHAR, SQL_CHAR,
							   0, 0, &z, 0, NULL);
		(void)SQLBindParameter(stmt, 2, SQL_PARAM_INPUT,
							   SQL_C_CHAR, SQL_CHAR,
							   0, 0, &z, 0, NULL);

		(void)SQLExecute(stmt);

		(void)SQLBindCol(stmt, 1, SQL_C_CHAR, (SQLCHAR *)y, BufferLength, NULL);
		(void)SQLBindCol(stmt, 2, SQL_C_CHAR, (SQLCHAR *)q, BufferLength, NULL);
		(void)SQLBindCol(stmt, 3, SQL_C_CHAR, (SQLCHAR *)p, BufferLength, NULL);
		(void)SQLBindCol(stmt, 4, SQL_C_CHAR, (SQLCHAR *)l, BufferLength, NULL);

		if (buffer == NULL) {
			return ;
		}
		while (SQL_SUCCEEDED(ret = SQLFetch(stmt)))
		{
			buffer[j] = malloc(sizeof(char *) * 4);
			if (buffer[j] == NULL) {
				flag = 1;
				break;
			}
			buffer[j][0] = malloc(sizeof(char) * strlen(y) + 1);
			strcpy(buffer[j][0], y);
			if (buffer[j][0] == NULL) {
				flag = 1;
				break;
			}
			buffer[j][1] = malloc(sizeof(char) * strlen(q) + 1);
			strcpy(buffer[j][1], q);
			if (buffer[j][1] == NULL) {
				flag = 1;
				break;
			}
			buffer[j][2] = malloc(sizeof(char) * strlen(p) + 1);
			strcpy(buffer[j][2], p);
			if (buffer[j][2] == NULL) {
				flag = 1;
				break;
			}
			buffer[j][3] = malloc(sizeof(char) * strlen(l) + 1);
			strcpy(buffer[j][3], l);
			if (buffer[j][3] == NULL) {
				flag = 1;
				break;
			}
			j++;
		}
		if (flag == 1)
		{
			while (i < j)
			{
				free(buffer[i][0]);
				free(buffer[i][1]);
				free(buffer[i][2]);
				free(buffer[i][3]);
				free(buffer[i]);
				i++;
			}
			free(buffer);
			return ;
		}

		u = 0;
		if (j >= 10)
		{
			while (1 == 1)
			{
				while (i < 10 && buffer[u] != NULL)
				{
					printf("%s %s %s %s\n", buffer[u][0], buffer[u][1], buffer[u][2], buffer[u][3]);
					i++;
					u++;
				}
				if (page == 0)
					printf("\n '>' to go forward, 'exit' to exit > ");
				else
					printf("\n '>' to go forward, '<' to go back, 'exit' to exit > ");
				char arrow[6] = "\0";
				if (fgets(arrow, (int)sizeof(arrow), stdin) == NULL)
				{
					u = 0;
					while (u < j)
					{
						free(buffer[u][0]);
						free(buffer[u][1]);
						free(buffer[u][2]);
						free(buffer[u][3]);
						free(buffer[u]);
						u++;
					}
					free(buffer);
					return;
				}
				x[strlen(x) - 1] = (char)0;
				printf("\n");
				if (strcmp(arrow, ">\n") == 0)
				{
					i = 0;
					page++;
				}
				else if (strcmp(arrow, "<\n") == 0)
				{
					i = 0;
					page--;
					u -= 20;
				}
				else if (strcmp(arrow, "exit\n") == 0)
				{
					i = 0;
					break;
				}
			}
		}
		else
		{
			while (i < 10 && buffer[u] != NULL)
			{
				printf("%s %s %s %s\n", buffer[u][0], buffer[u][1], buffer[u][2], buffer[u][3]);
				i++;
				u++;
			}
		}

		u = 0;
		while (u < j)
		{
			free(buffer[u][0]);
			free(buffer[u][1]);
			free(buffer[u][2]);
			free(buffer[u][3]);
			free(buffer[u]);
			u++;
		}
		free(buffer);

		(void)SQLCloseCursor(stmt);
	}


	ret2 = SQLFreeHandle(SQL_HANDLE_STMT, stmt);
	if (!SQL_SUCCEEDED(ret2))
	{
		odbc_extract_error("", stmt, SQL_HANDLE_STMT);
		return;
	}
	ret = odbc_disconnect(env, dbc);
	if (!SQL_SUCCEEDED(ret))
	{
		return;
	}
	printf("\n");
}


// Función que ejecuta la query correspondiente a la orden list_products de customers
// Autores: Marcos Alonso y Enrique Gómez

void customers_list_products()
{
	int ret = 0;
	int ret2 = 0;
	SQLHSTMT stmt = NULL;
	SQLHENV env = NULL;
	SQLHDBC dbc = NULL;
	int	i = 0;
	int	j = 0;
	int	z = 0;
	int	page = 0;
	int flag = 0;
	char ***buffer;
	char x[BufferLength] = "\0";
	char k[BufferLength] = "\0";
	char y[BufferLength] = "\0";

	ret = odbc_connect(&env, &dbc);
	if (!SQL_SUCCEEDED(ret))
	{
		return;
	}
	ret = SQLAllocHandle(SQL_HANDLE_STMT, dbc, &stmt);
	ret = SQLPrepare(stmt, (SQLCHAR *)"select products.productname, SUM(orderdetails.quantityordered) as Cantidad from orders NATURAL JOIN orderdetails join products on products.productcode=orderdetails.productcode where orders.customernumber=? GROUP BY products.productname, products.productcode ORDER BY products.productcode", SQL_NTS);
	if (!SQL_SUCCEEDED(ret))
	{
		odbc_extract_error("", stmt, SQL_HANDLE_ENV);
		return;
	}
	printf("Enter customer number > ");
	(void)fflush(stdout);
	if (fgets(x, (int)sizeof(x), stdin) != NULL)
	{
		x[strlen(x) - 1] = (char)0;
		(void)SQLBindParameter(stmt, 1, SQL_PARAM_INPUT,
							   SQL_C_CHAR, SQL_CHAR,
							   0, 0, &x, 0, NULL);

		(void)SQLExecute(stmt);

		(void)SQLBindCol(stmt, 1, SQL_C_CHAR, (SQLCHAR *)y, BufferLength, NULL);
		(void)SQLBindCol(stmt, 2, SQL_C_CHAR, (SQLCHAR *)k, BufferLength, NULL);

		buffer = malloc(sizeof(char **) * 1500);
		if (buffer == NULL) {
				return;
			}

		while (SQL_SUCCEEDED(ret = SQLFetch(stmt)))
		{
			buffer[j] = malloc(sizeof(char *) * 2);
			if (buffer[j] == NULL) {
				flag = 1;
				break;
			}
			buffer[j][0] = malloc(sizeof(char) * strlen(y) + 1);
			strcpy(buffer[j][0], y);
			if (buffer[j][0] == NULL) {
				flag = 1;
				break;
			}
			buffer[j][1] = malloc(sizeof(char) * strlen(k) + 1);
			strcpy(buffer[j][1], k);
			if (buffer[j][1] == NULL) {
				flag = 1;
				break;
			}
			j++;
		}
		if (flag == 1)
		{
			while (i < j)
			{
				free(buffer[i][0]);
				free(buffer[i][1]);
				free(buffer[i][2]);
				free(buffer[i][3]);
				free(buffer[i]);
				i++;
			}
			free(buffer);
			return ;
		}

		/* Loop through the rows in the result-set */
		z = 0;
		if (j >= 10)
		{
			while (1 == 1)
			{
				while (i < 10 && buffer[z] != NULL)
				{
					printf("%s %s\n", buffer[z][0], buffer[z][1]);
					i++;
					z++;
				}
				if (page == 0)
					printf("\n '>' to go forward, 'exit' to exit > ");
				else
					printf("\n '>' to go forward, '<' to go back, 'exit' to exit > ");
				char arrow[6] = "\0";
				if (fgets(arrow, (int)sizeof(arrow), stdin) == NULL)
				{
					z = 0;
					while (z < j)
					{
						free(buffer[z][0]);
						free(buffer[z][1]);
						free(buffer[z]);
						z++;
					}
					free(buffer);
					return;
				}
				x[strlen(x) - 1] = (char)0;
				printf("\n");
				if (strcmp(arrow, ">\n") == 0)
				{
					i = 0;
					page++;
				}
				else if (strcmp(arrow, "<\n") == 0)
				{
					i = 0;
					page--;
					z -= 20;
				}
				else if (strcmp(arrow, "exit\n") == 0)
				{
					i = 0;
					break;
				}
			}
		}
		else
		{
			while (i < 10 && buffer[z] != NULL)
			{
				printf("%s %s\n", buffer[z][0], buffer[z][1]);
				i++;
				z++;
			}
		}

		z = 0;
		while (z < j)
		{
			free(buffer[z][0]);
			free(buffer[z][1]);
			free(buffer[z]);
			z++;
		}
		free(buffer);

		(void)SQLCloseCursor(stmt);
	}


	ret2 = SQLFreeHandle(SQL_HANDLE_STMT, stmt);
	if (!SQL_SUCCEEDED(ret2))
	{
		odbc_extract_error("", stmt, SQL_HANDLE_STMT);
		return;
	}
	ret = odbc_disconnect(env, dbc);
	if (!SQL_SUCCEEDED(ret))
	{
		return;
	}
	printf("\n");
}


// Función que ejecuta la query correspondiente a la orden balance de customers
// Autores: Marcos Alonso y Enrique Gómez

void customers_balance()
{
	int ret = 0;
	int ret2 = 0;
	SQLHSTMT stmt = NULL;
	SQLHENV env = NULL;
	SQLHDBC dbc = NULL;
	char x[BufferLength] = "\0";
	char y[BufferLength] = "\0";

	ret = odbc_connect(&env, &dbc);
	if (!SQL_SUCCEEDED(ret))
	{
		return;
	}
	ret = SQLAllocHandle(SQL_HANDLE_STMT, dbc, &stmt);
	ret = SQLPrepare(stmt, (SQLCHAR *)"with suma as (select (priceeach*quantityordered) as cantidad, customers.customernumber as custo from orderdetails natural join orders natural join customers where customernumber=?), suma2 as ( select sum(amount) as total, customers.customernumber as custo from payments natural join customers where customernumber=? group by customers.customernumber ) select (suma2.total - sum(suma.cantidad)) from suma2 join suma on suma2.custo=suma.custo group by suma2.total", SQL_NTS);
	if (!SQL_SUCCEEDED(ret))
	{
		odbc_extract_error("", stmt, SQL_HANDLE_ENV);
		return;
	}
	printf("Enter customer number > ");
	(void)fflush(stdout);
	if (fgets(x, (int)sizeof(x), stdin) != NULL)
	{
		x[strlen(x) - 1] = (char)0;
		(void)SQLBindParameter(stmt, 1, SQL_PARAM_INPUT,
							   SQL_C_CHAR, SQL_CHAR,
							   0, 0, &x, 0, NULL);
		(void)SQLBindParameter(stmt, 2, SQL_PARAM_INPUT,
							   SQL_C_CHAR, SQL_CHAR,
							   0, 0, &x, 0, NULL);

		(void)SQLExecute(stmt);

		(void)SQLBindCol(stmt, 1, SQL_C_CHAR, (SQLCHAR *)y, BufferLength, NULL);

		/* Loop through the rows in the result-set */
		while (SQL_SUCCEEDED(ret = SQLFetch(stmt)))
		{
			printf("Balance = %s\n", y);
		}

		(void)SQLCloseCursor(stmt);
	}

	ret2 = SQLFreeHandle(SQL_HANDLE_STMT, stmt);
	if (!SQL_SUCCEEDED(ret2))
	{
		odbc_extract_error("", stmt, SQL_HANDLE_STMT);
		return;
	}
	ret = odbc_disconnect(env, dbc);
	if (!SQL_SUCCEEDED(ret))
	{
		return;
	}
	printf("\n");
}