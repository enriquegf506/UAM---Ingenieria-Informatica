#include "menu.h"
#include "products.h"

// Función que ejecuta la query correspondiente a la orden stock de products
// Autores: Marcos Alonso y Enrique Gómez

void	products_stock()
{
    int ret = 0;
    int ret2 = 0;
    SQLHSTMT stmt = NULL;
    SQLHENV env = NULL;
    SQLHDBC dbc = NULL;
    char x[BufferLength] = "\0";
    char y[BufferLength] = "\0";

	ret = odbc_connect(&env, &dbc);
    if (!SQL_SUCCEEDED(ret)) {
        return;
    }
    ret = SQLAllocHandle(SQL_HANDLE_STMT, dbc, &stmt);
    ret = SQLPrepare(stmt, (SQLCHAR*) "select quantityinstock from products where productcode=?", SQL_NTS);
    if (!SQL_SUCCEEDED(ret)) {
        odbc_extract_error("", stmt, SQL_HANDLE_ENV);
        return;
    }
    printf("Enter productcode > ");
    (void) fflush(stdout);
    if (fgets(x, (int) sizeof(x), stdin) != NULL) {
        x[strlen(x) - 1] = (char)0;
        (void) SQLBindParameter(stmt, 1, SQL_PARAM_INPUT,
                    SQL_C_CHAR, SQL_CHAR,
                    0, 0, &x, 0, NULL);

        (void) SQLExecute(stmt);
        
        (void) SQLBindCol(stmt, 1, SQL_C_CHAR,(SQLCHAR *) y, BufferLength, NULL);

        /* Loop through the rows in the result-set */
        while (SQL_SUCCEEDED(ret = SQLFetch(stmt))) {
            printf("%s\n", y);
        }

        (void) SQLCloseCursor(stmt);
    }
                
    ret2 = SQLFreeHandle(SQL_HANDLE_STMT, stmt);
    if (!SQL_SUCCEEDED(ret2)) {
        odbc_extract_error("", stmt, SQL_HANDLE_STMT);
        return;
    }
    ret = odbc_disconnect(env, dbc);
    if (!SQL_SUCCEEDED(ret)) {
        return;
    }
    printf("\n");
}

// Función que ejecuta la query correspondiente a la orden find de products
// Autores: Marcos Alonso y Enrique Gómez

void	products_find()
{
    int ret = 0;
    int ret2 = 0;
    SQLHSTMT stmt = NULL;
    SQLHENV env = NULL;
    SQLHDBC dbc = NULL;
	SQLUSMALLINT	i = 0;
    char x[BufferLength] = "\0";
    char y[BufferLength] = "\0";
	char n[BufferLength] = "\0";
	SQLSMALLINT columns = 0;
	SQLUSMALLINT ucolumns = 0;

	ret = odbc_connect(&env, &dbc);
	if (!SQL_SUCCEEDED(ret))
	{
		return;
	}
	ret = SQLAllocHandle(SQL_HANDLE_STMT, dbc, &stmt);
	ret = SQLPrepare(stmt, (SQLCHAR *)"select productname, productcode from products where productname like ?", SQL_NTS);
	if (!SQL_SUCCEEDED(ret))
	{
		odbc_extract_error("", stmt, SQL_HANDLE_ENV);
		return;
	}
	printf("Enter productname > ");
	(void)fflush(stdout);
	if (fgets(x, (int)sizeof(x), stdin) != NULL)
	{
		x[strlen(x) - 1] = (char)0;
		char z[BufferLength] = "\0";
		strcat(z, "%");
		strcat(z, x);
		strcat(z, "%");
		(void)SQLBindParameter(stmt, 1, SQL_PARAM_INPUT,
							   SQL_C_CHAR, SQL_CHAR,
							   0, 0, &z, 0, NULL);

		(void)SQLExecute(stmt);

		ret = SQLNumResultCols(stmt, &columns);
		if (!SQL_SUCCEEDED(ret))
		{
			odbc_extract_error("Error getting number of columns", stmt, SQL_HANDLE_STMT);
			return;
		}
		(void)SQLBindCol(stmt, 1, SQL_C_CHAR, (SQLCHAR *)y, BufferLength, NULL);
		(void)SQLBindCol(stmt, 2, SQL_C_CHAR, (SQLCHAR *)n, BufferLength, NULL);
		/* print the name of each column */
		ucolumns = (SQLUSMALLINT)columns;
		for (i = 1; i <= ucolumns; i++)
		{
			char buf[BufferLength] = "\0";

			ret = SQLDescribeCol(stmt, i, (SQLCHAR *)buf, BufferLength, NULL, NULL, NULL, NULL, NULL);
			if (!SQL_SUCCEEDED(ret))
			{
				odbc_extract_error("Error in SQLDescribeCol", stmt, SQL_HANDLE_STMT);
				return;
			}
			printf("%s\t", buf);
		}
		printf("\n");
		/* print the name of each column */
		ucolumns = (SQLUSMALLINT)columns;
		while (SQL_SUCCEEDED(ret = SQLFetch(stmt)))
		{
			printf("%s\t%s", y, n);
			printf("\n");
		}

		(void)SQLCloseCursor(stmt);
	}
	ret2 = SQLFreeHandle(SQL_HANDLE_STMT, stmt);
	if (!SQL_SUCCEEDED(ret2))
	{
		odbc_extract_error("", stmt, SQL_HANDLE_STMT);
		return;
	}
	printf("\n");
	ret = odbc_disconnect(env, dbc);
	if (!SQL_SUCCEEDED(ret))
	{
		return;
	}
}
