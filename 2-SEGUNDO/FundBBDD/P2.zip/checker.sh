#!/bin/bash
./products_stock.sh
sleep 1
./products_find.sh
sleep 1
./orders_open.sh
sleep 1
./orders_range.sh
sleep 1
./orders_detail.sh
sleep 1
./customers_find.sh
sleep 1
./customers_list_products.sh
sleep 1
./customers_balance.sh