#include "menu.h"
#include "orders.h"


// Función que ejecuta la query correspondiente a la orden open de orders
// Autores: Marcos Alonso y Enrique Gómez

void	orders_open()
{
    int ret = 0;
    int ret2 = 0;
    SQLHSTMT stmt = NULL;
    SQLHENV env = NULL;
    SQLHDBC dbc = NULL;
    char y[BufferLength] = "\0";


	ret = odbc_connect(&env, &dbc);
    if (!SQL_SUCCEEDED(ret)) {
        return;
    }

    /* Allocate a statement handle */
    ret = SQLAllocHandle(SQL_HANDLE_STMT, dbc, &stmt);
    if (!SQL_SUCCEEDED(ret)) {
        odbc_extract_error("", stmt, SQL_HANDLE_ENV);
        return;
    }
    /* simple query */
    ret = SQLPrepare(stmt, (SQLCHAR*) "select ordernumber from orders where shippeddate is Null", SQL_NTS);
    if (!SQL_SUCCEEDED(ret)) {
        odbc_extract_error("", stmt, SQL_HANDLE_STMT);
        return;
    }
    (void) SQLExecute(stmt);

    (void) SQLBindCol(stmt, 1, SQL_C_CHAR,(SQLCHAR *) y, BufferLength, NULL);

    /* Loop through the rows in the result-set */
    while (SQL_SUCCEEDED(ret = SQLFetch(stmt))) {
        printf("%s\n", y);
    }

    (void) SQLCloseCursor(stmt);

    ret2 = SQLFreeHandle(SQL_HANDLE_STMT, stmt);
    if (!SQL_SUCCEEDED(ret2)) {
        odbc_extract_error("", stmt, SQL_HANDLE_STMT);
        return;
    }
    printf("\n");
    ret = odbc_disconnect(env, dbc);
    if (!SQL_SUCCEEDED(ret)) {
        return;
    }

}

// Función que ejecuta la query correspondiente a la orden detail de orders
// Autores: Marcos Alonso y Enrique Gómez

void	orders_detail()
{
    int ret = 0;
    int ret2 = 0;
    SQLHSTMT stmt = NULL;
    SQLHENV env = NULL;
    SQLHDBC dbc = NULL;
	int flag = 1;
    char x[BufferLength] = "\0";
    char k[BufferLength] = "\0";
    char z[BufferLength] = "\0";
    char y[BufferLength] = "\0";
    char q[BufferLength] = "\0";
    char p[BufferLength] = "\0";
	char l[BufferLength] = "\0";

	ret = odbc_connect(&env, &dbc);
	if (!SQL_SUCCEEDED(ret))
	{
		return;
	}
	ret = SQLAllocHandle(SQL_HANDLE_STMT, dbc, &stmt);
	ret = SQLPrepare(stmt, (SQLCHAR *)"with suma as (select (priceeach*quantityordered) as total, ordernumber from orders natural join orderdetails where ordernumber=?)   select orders.orderdate, orders.status, sum(total), productcode, quantityordered, priceeach from orders natural join orderdetails natural join suma where ordernumber=? group by orders.orderdate, orders.status, orderdetails.productcode, orderdetails.quantityordered, orderdetails.priceeach, orderdetails.orderlinenumber order by orderlinenumber", SQL_NTS);
	if (!SQL_SUCCEEDED(ret))
	{
		odbc_extract_error("", stmt, SQL_HANDLE_ENV);
		return;
	}
	printf("Enter ordernumber > ");
	(void)fflush(stdout);
	if (fgets(x, (int)sizeof(x), stdin) != NULL)
	{
		x[strlen(x) - 1] = (char)0;
		(void)SQLBindParameter(stmt, 1, SQL_PARAM_INPUT,
							   SQL_C_CHAR, SQL_CHAR,
							   0, 0, &x, 0, NULL);
		(void)SQLBindParameter(stmt, 2, SQL_PARAM_INPUT,
							   SQL_C_CHAR, SQL_CHAR,
							   0, 0, &x, 0, NULL);

		(void)SQLExecute(stmt);

		(void)SQLBindCol(stmt, 1, SQL_C_CHAR, (SQLCHAR *)y, BufferLength, NULL);
		(void)SQLBindCol(stmt, 2, SQL_C_CHAR, (SQLCHAR *)k, BufferLength, NULL);
		(void)SQLBindCol(stmt, 3, SQL_C_CHAR, (SQLCHAR *)z, BufferLength, NULL);
		(void)SQLBindCol(stmt, 4, SQL_C_CHAR, (SQLCHAR *)p, BufferLength, NULL);
		(void)SQLBindCol(stmt, 5, SQL_C_CHAR, (SQLCHAR *)q, BufferLength, NULL);
		(void)SQLBindCol(stmt, 6, SQL_C_CHAR, (SQLCHAR *)l, BufferLength, NULL);

		/* Loop through the rows in the result-set */
		while (SQL_SUCCEEDED(ret = SQLFetch(stmt)))
		{
			if (flag == 1)
			{
				printf("%s %s\n%s\n", y, k, z);
				flag = 0;
			}
			printf("%s %s %s\n", p, q, l);
		}
		flag = 1;

		(void)SQLCloseCursor(stmt);
	}

	ret2 = SQLFreeHandle(SQL_HANDLE_STMT, stmt);
	if (!SQL_SUCCEEDED(ret2))
	{
		odbc_extract_error("", stmt, SQL_HANDLE_STMT);
		return;
	}
	ret = odbc_disconnect(env, dbc);
	if (!SQL_SUCCEEDED(ret))
	{
		return;
	}
	printf("\n");
}

// Función que ejecuta la query correspondiente a la orden range de orders
// Autores: Marcos Alonso y Enrique Gómez

void	orders_range()
{
    int ret = 0;
    int ret2 = 0;
    int i = 0;
    int j = 0;
    SQLHSTMT stmt = NULL;
    SQLHENV env = NULL;
    SQLHDBC dbc = NULL;
    char x[BufferLength] = "\0";
    char k[BufferLength] = "\0";
    char z[BufferLength] = "\0";
    char y[BufferLength] = "\0";
    char q[BufferLength] = "\0";
    char p[BufferLength] = "\0";

	ret = odbc_connect(&env, &dbc);
	if (!SQL_SUCCEEDED(ret))
	{
		return;
	}
	ret = SQLAllocHandle(SQL_HANDLE_STMT, dbc, &stmt);
	ret = SQLPrepare(stmt, (SQLCHAR *)"select ordernumber, orderdate, shippeddate from orders where orders.orderdate >= ? AND orders.orderdate <= ?", SQL_NTS);
	if (!SQL_SUCCEEDED(ret))
	{
		odbc_extract_error("", stmt, SQL_HANDLE_ENV);
		return;
	}
	printf("Enter dates (YYYY-MM-DD - YYYY-MM-DD) > ");
	(void)fflush(stdout);

	if (fgets(x, (int)sizeof(x), stdin) != NULL)
	{
		x[strlen(x) - 1] = (char)0;
		while (i < 10)
		{
			z[i] = x[i];
			i++;
		}
		z[i] = (char)0;
		i += 3;
		while (x[i] != '\0')
			k[j++] = x[i++];
		k[j] = (char)0;
		// printf("%s, %s",z,k);
		(void)SQLBindParameter(stmt, 1, SQL_PARAM_INPUT,
							   SQL_C_CHAR, SQL_CHAR,
							   0, 0, &z, 0, NULL);

		(void)SQLBindParameter(stmt, 2, SQL_PARAM_INPUT,
							   SQL_C_CHAR, SQL_CHAR,
							   0, 0, &k, 0, NULL);

		(void)SQLExecute(stmt);

		(void)SQLBindCol(stmt, 1, SQL_C_CHAR, (SQLCHAR *)y, BufferLength, NULL);
		(void)SQLBindCol(stmt, 2, SQL_C_CHAR, (SQLCHAR *)q, BufferLength, NULL);
		(void)SQLBindCol(stmt, 3, SQL_C_CHAR, (SQLCHAR *)p, BufferLength, NULL);

		/* Loop through the rows in the result-set */
		while (SQL_SUCCEEDED(ret = SQLFetch(stmt)))
		{
			printf("%s %s %s\n", y, q, p);
		}

		(void)SQLCloseCursor(stmt);
	}

	ret2 = SQLFreeHandle(SQL_HANDLE_STMT, stmt);
	if (!SQL_SUCCEEDED(ret2))
	{
		odbc_extract_error("", stmt, SQL_HANDLE_STMT);
		return;
	}
	ret = odbc_disconnect(env, dbc);
	if (!SQL_SUCCEEDED(ret))
	{
		return;
	}
	printf("\n");
}