#include <stdlib.h>
#include <stdio.h>
#include <sql.h>
#include <sqlext.h>
#include <string.h>
#include <ctype.h>
#include "odbc.h"

#define BufferLength 512

