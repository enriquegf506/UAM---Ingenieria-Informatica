#include "menu.h"

void	customers_find();
void	customers_list_products();
void	customers_balance();