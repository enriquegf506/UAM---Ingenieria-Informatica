#include "menu.h"

void	orders_open();
void	orders_detail();
void	orders_range();