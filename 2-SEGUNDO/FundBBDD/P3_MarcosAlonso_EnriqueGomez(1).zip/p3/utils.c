/*
 * Created by Enrique and Marcos on 20/11/22.
 */
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdbool.h>
#include "utils.h"
#include <sys/stat.h>

static int no_deleted_registers = NO_DELETED_REGISTERS;

void replaceExtensionByIdx(const char *fileName, char * indexName) 
{
    strncpy(indexName, fileName, strlen(fileName) - 3);
    strcat(indexName, "idx");
}


bool createTable(const char * tableName) 
{
    int output=EXIT_FAILURE;
    FILE * datafile = NULL;
    char * indexName = NULL;

    /*Intentamos abrir el fichero y si no existe lo creamos*/
    datafile = fopen(tableName, "rb+");

    if (datafile == NULL) 
    {
        datafile = fopen(tableName, "wb+");
        if (datafile == NULL)
            return EXIT_FAILURE;
        fwrite(&no_deleted_registers, sizeof(int), 1, datafile);
    }
    
    fclose(datafile);
    /* Reservamos memoria para llamar a la función y crear el idex, cambiando el nombre a .idx*/
    indexName = (char *) calloc((strlen(tableName) + 1), sizeof(char));
	if (indexName == NULL)
		return EXIT_FAILURE;

	replaceExtensionByIdx(tableName, indexName);
    output = createIndex(indexName);
    free(indexName);
    return (output);
}


bool createIndex(const char *indexName) 
{
    FILE * indexfile = NULL;

	/* intenta abrir el archivo y si no existe lo creamos*/
    indexfile = fopen(indexName, "rb+");
    
    if (indexfile == NULL) 
    {
        indexfile = fopen(indexName, "wb+");
        if (indexfile == NULL)
            return EXIT_FAILURE;
		/* escribimos las cabeceras*/
        fwrite(&no_deleted_registers, sizeof(int), 1, indexfile);
        fwrite(&no_deleted_registers, sizeof(int), 1, indexfile);
    }
    fclose(indexfile);
    
    return EXIT_SUCCESS;
}


static void printnode(size_t _level, size_t level, FILE * indexFileHandler, int node_id, char side)
 {
    size_t i;
    size_t size;
    size_t REGISTER_SIZE;
    Node node;

	/* caso base de la recursión*/
    if (node_id == -1)
       return;
    if (_level>level)
        return;
	/*hacemos fseek para leer el nodo node_id*/
    REGISTER_SIZE = sizeof(node);
    size = INDEX_HEADER_SIZE + REGISTER_SIZE * node_id;
    fseek(indexFileHandler, size, SEEK_SET);
    fread(&node, sizeof(Node), 1, indexFileHandler);
	/* depende del nivel, escribimos mas o menos tabulaciones*/
    for (i=0; i< _level; i++)
        printf("\t");
    printf("%c %.4s (%d): %d\n",
           side, node.book_id, node_id, node.offset);

    _level++;
	/* llamadas recurisvas a los hijos del nodo*/
    printnode(_level, level, indexFileHandler, node.left, 'l');
    printnode(_level, level, indexFileHandler, node.right, 'r');
}


void printTree(size_t level, const char * indexName)
{
    int n_id;
    FILE * indexFileHandler = NULL;

    /* intenta abrir el archivo */
    indexFileHandler = fopen(indexName, "r");
	if (indexFileHandler == NULL)
		return ;
    /* donde está root */
    fread(&n_id, sizeof(int), 1, indexFileHandler);
    if (n_id == -1)
        return;
    /* lee el primer nodo */
    printnode(0, level, indexFileHandler, n_id, ' ');
	fclose(indexFileHandler);
}


bool findKey(const char * book_id, const char *indexName, int * nodeIDOrDataOffset)
{
    FILE * indexfile = NULL;
    size_t size=0; 
    size_t REGISTER_SIZE=0;
    int aux;
    int ini=-1;
    Node node;

    /* fetch root node */
    indexfile = fopen(indexName, "rb+");
	if (indexfile == NULL)
		return false;
    fread(&ini, sizeof(int), 1, indexfile);
    REGISTER_SIZE = sizeof(Node);
    *nodeIDOrDataOffset = ini;

	node.left = 0;
	node.right = 0;
    while(true)
    {
        size = INDEX_HEADER_SIZE + REGISTER_SIZE * (*nodeIDOrDataOffset);
        fseek(indexfile, size, SEEK_SET);
        fread(&node, sizeof(Node), 1, indexfile);
        aux = memcmp(book_id, node.book_id,PK_SIZE);
        if (aux == 0)
        {
            *nodeIDOrDataOffset = node.offset;
            fclose(indexfile);
            return true;
        }
        else if (aux > 0)
        {
            if (node.right == -1 || ini == -1)
            {
                fclose(indexfile);
                return false;
            } else
                *nodeIDOrDataOffset = node.right;
        }
        else 
        {
            if (node.left  == -1 || ini == -1)
            {
                fclose(indexfile);
                return false;
            } 
            else
                *nodeIDOrDataOffset = node.left;
        }
    }
}


bool addIndexEntry(char * book_id,  int bookOffset, char const * indexName)
{
    FILE *indexFileHandler = NULL;
    int nodeIDOrDataOffset;
    int aux = -1;
    int del = -1;
    int new_node = -1;
    size_t INDEX_REGISTER_SIZE = sizeof(Node);
    Node node;
    struct stat st;

    /* si la key existe devuelve false */
    aux = findKey(book_id, indexName, &nodeIDOrDataOffset);
    if (aux)
        return false;

    /* añade nueva key */
    /* comprueba registros borrados */
    indexFileHandler = fopen(indexName, "rb+");
	if (indexFileHandler == NULL)
		return false;
    /* salta al nodo root */
    aux = fread(&del, sizeof(int), 1, indexFileHandler);
    /* lee puntero a lista de nodos borrados */
    aux = fread(&del, sizeof(int), 1, indexFileHandler);
    /* usa espacio disponible si se puede*/
    if (del != -1) 
    {
        /* lee nodo borrado */
        aux = fseek(indexFileHandler,del * INDEX_REGISTER_SIZE + INDEX_HEADER_SIZE,SEEK_SET);
        aux = fread(&node, INDEX_REGISTER_SIZE, 1, indexFileHandler);
        new_node = del;
        del = node.left;
        /* actualiza cabecera */
        aux = fseek(indexFileHandler, sizeof(int), SEEK_SET);
        aux = fwrite(&del, sizeof(int), 1, indexFileHandler);
        /* mueve puntero de los nodos borrados*/
        aux = fseek(indexFileHandler, new_node * INDEX_REGISTER_SIZE + INDEX_HEADER_SIZE, SEEK_SET);
    }
    /* añade nodo al final del fichero */
    else
    {
        aux = fseek(indexFileHandler, 0, SEEK_END);
        stat(indexName, &st);
        new_node = ((st.st_size - INDEX_HEADER_SIZE) / INDEX_REGISTER_SIZE );
    }
    memcpy(node.book_id, book_id,4);
    node.offset = bookOffset;
    node.right = -1;
    node.left = -1;
    node.parent = nodeIDOrDataOffset;
	if (new_node == 0)
	{
		aux = fseek(indexFileHandler, 0, SEEK_SET);
		fwrite(&new_node, sizeof(int), 1, indexFileHandler);
		aux = fseek(indexFileHandler, 0, SEEK_END);
	}
    aux = fwrite(&node, INDEX_REGISTER_SIZE, 1, indexFileHandler);
    /* lee el padre y lo actualiza */
	if (new_node != 0)
	{
    	aux = fseek(indexFileHandler, nodeIDOrDataOffset * INDEX_REGISTER_SIZE + INDEX_HEADER_SIZE, SEEK_SET);
    	aux = fread(&node, INDEX_REGISTER_SIZE, 1, indexFileHandler);
    	if (memcmp(book_id,node.book_id,4) <0)
        	node.left = new_node;
    	else
        	node.right = new_node;
    	aux = fseek(indexFileHandler, nodeIDOrDataOffset * INDEX_REGISTER_SIZE + INDEX_HEADER_SIZE, SEEK_SET);
    	aux = fwrite(&node, INDEX_REGISTER_SIZE, 1, indexFileHandler);
	}
	aux = fclose(indexFileHandler);
    return true;
}


bool addTableEntry(Book * book, const char * dataName, const char * indexName)
{
    FILE *dataFileHandler = NULL;
    int del = -1;
    int nodeIDOrDataOffset;
    int aux = -1;
	int offset;
    struct stat st;


    /* si key existe devuelve false */
    aux = findKey(book->book_id, indexName, &nodeIDOrDataOffset);
    if (aux)
        return false;

    /* añade nueva key */
    /* mira registros borrados */
    dataFileHandler = fopen(dataName, "rb+");
	if (dataFileHandler == NULL)
		return false;
    /* lee el puntero a los registros borrados */
    fread(&del, sizeof(int), 1, dataFileHandler);
    if (del != -1) 
    {
		return false;
    }
	/* escribe al final del fichero*/
    else
    {
        fseek(dataFileHandler, 0, SEEK_END);
        stat(dataName, &st);
		offset = st.st_size;
    }
    
    fwrite(book->book_id, PK_SIZE, 1, dataFileHandler);
	fwrite(&book->title_len, sizeof(int), 1, dataFileHandler);
	fwrite(book->title, book->title_len, 1, dataFileHandler);
    
    fclose(dataFileHandler);
	/* llamamos a addindexentry para modificar el .idx*/
	addIndexEntry(book->book_id, offset, indexName);
    return true;
}
