/*
// Created by marcos and kawasakis on 30/8/20.
*/
#include "tester.h"

void checkAddTableEntry(const char * tableName)
{
	bool result;
	Book *book;
	Book *book2;
	char *indexName;
	FILE *fp;
	int tmp = -1;

	createTestDataFile(tableName);
	indexName = (char *) calloc((strlen(tableName) + 1), sizeof(char));
	if (indexName == NULL)
		exit(EXIT_FAILURE);
	replaceExtensionByIdx(tableName, indexName);
	printf("-----Original tree-------\n");
    printTree(4, indexName);
	/* añade un nuevo nodo al árbol*/
	book = malloc(sizeof(Book));
	book->title = malloc(sizeof(char) * 20);
	strcpy(book->book_id, "VAR2");
	strcpy(book->title, "Kitos Te Padrea");
	book->title_len = 15;	
    result = addTableEntry(book, tableName, indexName);
	if (result == false)
		exit(EXIT_FAILURE);
    printf("-----after adding VAR2-------\n");
    printTree(4, indexName);
	fp = fopen(tableName, "r");
    fread(&tmp, sizeof(int), 1, fp);
	/* tmp tiene que ser 71, el offset del primer nodo borrado*/
	if (tmp!=71){
        fprintf(stderr,
                "Error in addTableEntry, first int in file should be 71");
        exit(EXIT_FAILURE);
    }
	/* añade un nuevo nodo al árbol*/
	book2 = malloc(sizeof(Book));
	book2->title = malloc(sizeof(char) * 20);
	strcpy(book2->book_id, "VAR4");
	strcpy(book2->title, "esplendido");
	book2->title_len = 10;	
    result = addTableEntry(book2, tableName, indexName);
	if (result == false)
		exit(EXIT_FAILURE);
    printf("-----after adding VAR4-------\n");
	printTree(5, indexName);
	free(book->title);
	free(book);
	free(book2->title);
	free(book2);
	free(indexName);
	fclose(fp);
	printf("* AddTableEntry: OK\n");
	exit(EXIT_SUCCESS);
}