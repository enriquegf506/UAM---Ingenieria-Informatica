/* Autor: Roberto Marabini */
/* This file implements a set of unitary and functional tests
 * (not necessarily complete) designed to test the
 * methods that you are required to implement in this assignment
 *
 * We recommend you to follow a Test-driven development (TDD)
 * that is, execute the first test, which will fail, then create the code
 * to fix the errors and rerun the tests. Once the first test is
 * satisfied and the requirements for the first method are met
 * uncomment the second test and repeat the process
 *
 * IMPORTANT: do NOT modify the code in this file
 * but you are welcomed to add new tests
 */

#include "tester.h"

void checkReplaceExtensionByIdx(const char * tableName,
                                const char * indexName);
void checkCreateIndex(const char * indexName);
void checkCreateTable(const char * tableName);
void checkAddTableEntry(const char * tableName);
void checkPrint(const char * indexName);
void createTestIndexFile(const char * indexName);
void checkFindKey(const char * indexName);
void checkAddIndexEntry(const char * indexName);
Node a[TEST_ARRAY_SIZE];
char sort_a[SORTED_TEST_ARRAY_SIZE][PK_SIZE+1];
Book b[TEST_ARRAY_SIZE];

int main() {

	// // // TEST NUMERO 1

    const char *tableName = "myDataBase.dat";
    const char *indexName = "myDataBase.idx";

    /* remove file if exists */
    remove(tableName);
    remove(indexName);

	checkCreateIndex(indexName);
    checkCreateTable(tableName);
    createTestFiles(tableName, indexName);
    checkPrint(indexName);
    checkFindKey(indexName);
    checkAddIndexEntry(indexName);
	remove(tableName);
    remove(indexName);
	createTestFiles(tableName, indexName);
	checkAddTableEntry(tableName);

	// // // TEST NUMERO 2

	// Book *c;
	// Book *d;
	// Book *e;
	// Book *f;
	// Book *g;

	// c = malloc(sizeof(Book));
	// c->title = malloc(sizeof(char) * 20);
	// strcpy(c->book_id, "HEY4");
	// strcpy(c->title, "Kitos Te Padrea");
	// c->title_len = 15;
	// d = malloc(sizeof(Book));
	// d->title = malloc(sizeof(char) * 20);
	// strcpy(d->book_id, "UND4");
	// strcpy(d->title, "Mamadutenduten");
	// d->title_len = 14;
	// e = malloc(sizeof(Book));
	// e->title = malloc(sizeof(char) * 20);
	// strcpy(e->book_id, "AAA4");
	// strcpy(e->title, "Kitos Te Padreaa");
	// e->title_len = 16;
	// f = malloc(sizeof(Book));
	// f->title = malloc(sizeof(char) * 20);
	// strcpy(f->book_id, "ZZZ4");
	// strcpy(f->title, "Mamadutendutenn");
	// f->title_len = 15;
	// g = malloc(sizeof(Book));
	// g->title = malloc(sizeof(char) * 20);
	// strcpy(g->book_id, "BBB4");
	// strcpy(g->title, "Mamadutendutenn");
	// g->title_len = 15;

	// createTable("mitabla.dat");
	// addTableEntry(c, "mitabla.dat", "mitabla.idx");
	// addTableEntry(d, "mitabla.dat", "mitabla.idx");
	// addTableEntry(e, "mitabla.dat", "mitabla.idx");
	// addTableEntry(f, "mitabla.dat", "mitabla.idx");
	// addTableEntry(g, "mitabla.dat", "mitabla.idx");
	// printTree(2, "mitabla.idx");
#ifdef NEVERDEFINED
#endif
    return (0);
}

