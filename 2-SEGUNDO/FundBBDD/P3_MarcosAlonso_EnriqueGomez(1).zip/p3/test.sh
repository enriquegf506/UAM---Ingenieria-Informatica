#!/usr/bin/expect -f

set timeout -1

spawn ./menu

expect "Enter a number that corresponds to your choice > "
send -- "1\r"

expect "Enter file name > "
send -- "Test\r"

expect "Enter a number that corresponds to your choice > "
send -- "2\r"
for {set i 1000} {$i < 9998} {incr i 1} {

	expect "Enter key > "
	send -- "$i\r"

	expect "Enter title > "
	send -- "Prueba\r"

	expect "Enter a number that corresponds to your choice > "
	send -- "2\r"
}

expect "Enter key > "
send -- "9999\r"

expect "Enter title > "
send -- "Prueba\r"

expect "Enter a number that corresponds to your choice > "
send -- "3\r"

expect "Enter a number that corresponds to your choice > "
send -- "4\r"

expect eof