/*
 * Created by Enrique and Marcos on 27/8/20.
 */

#include "menu.h"
#include "utils.h"



int main(void) {
    int nChoice = 0;
    int use=0;
    char name[BufferLength]="\0";
	char *aux;

    do {
        nChoice = ShowMainMenu();
        switch (nChoice) {
            case 1: {
				aux = ShowUse();
                strcpy(name, aux);
                if(name == NULL){
                    printf("Error creating table.\n");
                }
                else {
                    printf("Table createde\n");
                    /*La tabla ha sido creada, por lo que podrán llamar a insert y a print*/
                    use=1;
                }
            }
                break;

            case 2: {
                if(use == 1)
                    if (ShowInsert(name) == EXIT_SUCCESS)
                        printf("Successfull insertion.\n");
                    else
                        printf("Error in insertion.\n");
                else
                    printf("Need to call use first.\n");

            }
                break;

            case 3: {
                if(use == 1)
                    ShowPrint(name);
                else
                    printf("Error, need to call use first.\n");
            }
                break;
            
            case 4: {
				free(aux);
                printf("Bye Bye\n\n");
            }
                break;
        }

        
    } while (nChoice != 4);

}


int ShowMainMenu() {
    int nSelected = 0;
    int i = 0;
    char buf[16]; 

    do {
        printf("This is a menu a user\n");
        printf("You can choose: \n\n");

        printf(" (1) Use\n"
               " (2) Insert\n"
               " (3) Print\n"
               " (4) Exit\n\n"
               "Enter a number that corresponds to your choice > ");
               nSelected = 0;
		(void)fflush(stdout);
        if (!fgets(buf, 16, stdin))
            /* la lectura falló, renuncia: */
            nSelected =0;
        else
        {
            /* tiene alguna entrada, conviértala en entero: */
            while(buf[i])
            {
                if isalpha(buf[i])
                {
                    nSelected = 5;
                    break;
                }
                i++;
            }
            if (nSelected != 5)
                nSelected = atoi(buf);
        }
        printf("\n");

        if ((nSelected < 1) || (nSelected > 4)) {
            printf("You have entered an invalid choice. Please try again\n\n\n");
        }
    } while ((nSelected < 1) || (nSelected > 4));

    return nSelected;
}

char *ShowUse(){

    char *x;
    x = malloc(sizeof(char) * BufferLength);
	if (!x)
		return NULL;

    printf("Enter file name > ");
    (void)fflush(stdout);
    /*Guardamos la cadena y le añadimos el .dat*/
    if (fgets(x, BufferLength, stdin) != NULL){
		x[strlen(x) - 1] = 0;
        strcat(x, ".dat");
        if(createTable(x) == EXIT_SUCCESS){
            return x;
        }
        else
            return NULL;
    }
    else
        return NULL;

}


int ShowInsert(char *tablename){

    char x[PK_SIZE+2] = "\0";
    char y[BufferLength] = "\0";
    char indexname[BufferLength] = "\0";
	int aux;
    Book *book=NULL;
    
    /*Nos pasan el nombre de la tabla como puntero y la cambiamos a .idx*/
    strncpy(indexname, tablename, strlen(tablename) - 3);
    strcat(indexname, "idx");

    book = malloc(sizeof(Book));
	if (!book)
		return EXIT_FAILURE;
	book->title = malloc(sizeof(char) * BufferLength);
	if (!book->title)
		return EXIT_FAILURE;
	
    printf("Enter key > ");
    (void)fflush(stdout);
    /*Recogemos la información de un book y la guardamos para insertarla*/
    if (fgets(x, (int)sizeof(x), stdin) != NULL){
		if (findKey(x, indexname, &aux) == true)
		{
			printf("Repeated key.\n");
			free(book->title);
			free(book);
			return EXIT_FAILURE;
		}
		if (x[4] != '\n')
		{
			char *p;
            if ( (p = strchr(x, '\n')))
			{
                *p = 0;
            }
			else
			{
                scanf("%*[^\n]");scanf("%*c");
            }
			free(book->title);
			free(book);
			return EXIT_FAILURE;
		}
        printf("Enter title > ");
        (void)fflush(stdout);
        /*Insertamos el libro */
        if (fgets(y, (int)sizeof(y), stdin) != NULL){
            strcpy(book->book_id, x);
	        strcpy(book->title, y);
            book->title_len= strlen(y);
            if(addTableEntry(book, tablename, indexname) == false){
				free(book->title);
				free(book);
                return EXIT_FAILURE;
            }
        }
        else
		{
			free(book->title);
			free(book);
            return EXIT_FAILURE;
		}
			
    }
    else
    {
		free(book->title);
		free(book);
        return EXIT_FAILURE;
	}
    free(book->title);
	free(book);
    return EXIT_SUCCESS;

}


void ShowPrint(char *tablename){

    char indexname[BufferLength] = "\0";
    
    /*Nos pasan el nombre de la tabla como puntero y la cambiamos a .idx*/
    strncpy(indexname, tablename, strlen(tablename) - 3);
    strcat(indexname, "idx");

	printTree(10000, indexname);
    
    return;

}