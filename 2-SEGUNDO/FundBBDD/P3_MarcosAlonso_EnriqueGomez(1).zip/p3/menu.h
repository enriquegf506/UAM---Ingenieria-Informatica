/*
 * Created by Enrique and Marcos on 8/12/20.
 */

#ifndef CODE_V2_MENU_H
#define CODE_V2_MENU_H
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "tester.h"
#include "utils.h"
#define BufferLength 512

int ShowMainMenu();
char *ShowUse();
int ShowInsert(char *tablename);
void ShowPrint(char *tablename);


#endif


