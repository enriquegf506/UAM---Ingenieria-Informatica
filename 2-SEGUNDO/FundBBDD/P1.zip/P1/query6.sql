


select
    o1.productcode,
    o2.productcode,
    count(o1.ordernumber) as carro
from
    orderdetails o1 
    join orderdetails o2 on o2.ordernumber=o1.ordernumber 
where 
    o1.productcode<>o2.productcode 
group by 
    (o1.productcode, o2.productcode)
having
    (count(o1.ordernumber)>1) and o1.productcode<o2.productcode


