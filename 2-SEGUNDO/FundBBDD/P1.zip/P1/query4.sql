



with total as (
    SELECT 
        officecode, count(*) as total
    FROM 
        offices 
        natural join employees 
        join customers on employeenumber=salesrepemployeenumber 
        natural join orders
        natural join orderdetails
    GROUP by officecode
    ORDER by total DESC)
select 
    officecode, total as totalSell
from 
    total
where 
    total in (select 
                    MAX(total)
                from 
                    total)