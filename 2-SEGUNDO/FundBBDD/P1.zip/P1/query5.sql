



(SELECT distinct 
    officecode
from 
    offices 
    natural join employees
    join customers on customers.salesrepemployeenumber=employees.employeenumber)
EXCEPT
(SELECT 
    officecode, orders.customernumber, customers.salesrepemployeenumber
from 
    offices 
    natural join employees
    join customers on customers.salesrepemployeenumber=employees.employeenumber
    natural join orders
where 
    orders.orderdate<='2003-12-31' and orders.orderdate>='2003-1-1')

