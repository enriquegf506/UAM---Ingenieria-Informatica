


SELECT
    productlines.productline, 
    AVG(orders.shippeddate-orders.orderdate) as tiempo
FROM
    productlines 
    JOIN products ON products.productline=productlines.productline
    JOIN orderdetails ON orderdetails.productcode=products.productcode
    JOIN orders ON orderdetails.ordernumber=orders.ordernumber

GROUP BY 
    productlines.productline