

with compradores as(
    select distinct 
        customernumber, customername
    from
        products 
        natural join orderdetails 
        natural join orders 
        natural join customers
    where productname = '1940 Ford Pickup Truck')
select 
    customernumber, customername, sum(amount) as suma
from
    compradores 
    natural join payments 
group by (customernumber, customername)
order by suma
desc    


