


select
    e1.employeenumber, e1.lastname
from
    employees e1 
    join employees e2 on e1.reportsto=e2.employeenumber
where 
    e2.reportsto = (
        select
            e.employeenumber
        from 
            employees e
        where
            e.reportsto is null)